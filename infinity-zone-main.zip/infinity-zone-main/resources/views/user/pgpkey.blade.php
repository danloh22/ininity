<pre>@if(!is_null($key)){{ $key }}@else You don't have a PGP key yet! @endif</pre>
