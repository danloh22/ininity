<script type="text/javascript">
    document.write("Hey!!!, You have Javascript on. You are putting yourself at risk!")
 </script>