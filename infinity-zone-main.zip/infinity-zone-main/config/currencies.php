<?php

return [

	'USD' => 'USD',
	'EUR' => 'EUR',
	'GBP' => 'GBP',
	'JPY' => 'JPY',
	'CHF' => 'CHF',
	'AUD' => 'AUD',
	'CAD' => 'CAD',
	'CNY' => 'CNY',
	'NZD' => 'NZD',
	'INR' => 'INR',
	'BRL' => 'BRL',
	'SEK' => 'SEK',
	'AFN' => 'AFN',
	'ZAR' => 'ZAR',
	'HKD' => 'HKD',
	'CNY' => 'CNY',
	'BMD' => 'BMD',
	'MXN' => 'MXN',
	'ARS' => 'ARS',
	'JMD' => 'JMD',
	'ZAR' => 'ZAR',
	'RUB' => 'RUB'
	
];